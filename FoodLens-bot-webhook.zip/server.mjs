import { createServer } from "node:http";
import { createReadStream } from "node:fs";
import { extname, join, normalize } from "node:path";

const root = new URL(".", import.meta.url).pathname;
const port = Number(process.env.PORT || 4173);
const telegramToken = process.env.TELEGRAM_BOT_TOKEN || "";
const appUrl = process.env.MINI_APP_URL || "https://food-lens-five.vercel.app";
const types = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8" };

function sendJson(response, status, payload) {
  response.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  response.end(JSON.stringify(payload));
}

function readJson(request) {
  return new Promise((resolve, reject) => {
    let body = "";
    request.on("data", (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) {
        request.destroy();
        reject(new Error("Payload too large"));
      }
    });
    request.on("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (error) {
        reject(error);
      }
    });
    request.on("error", reject);
  });
}

async function callTelegram(method, payload) {
  if (!telegramToken) return;
  await fetch(`https://api.telegram.org/bot${telegramToken}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}

async function handleTelegramWebhook(request, response) {
  try {
    const update = await readJson(request);
    const message = update.message;
    const chatId = message?.chat?.id;
    const text = message?.text || "";

    if (!chatId) {
      sendJson(response, 200, { ok: true });
      return;
    }

    const isHelp = text.startsWith("/help");
    const replyText = isHelp
      ? "Открой FoodLens, добавляй еду по фото или вручную, следи за калориями, БЖУ, водой и весом. AI-чат поможет разобрать день."
      : "Привет! Я FoodLens — AI-помощник по питанию. Открой мини-приложение и веди дневник еды, воды, веса и целей.";

    await callTelegram("sendMessage", {
      chat_id: chatId,
      text: replyText,
      reply_markup: {
        inline_keyboard: [[
          { text: "Открыть FoodLens", web_app: { url: appUrl } },
        ]],
      },
    });

    sendJson(response, 200, { ok: true });
  } catch (error) {
    sendJson(response, 200, { ok: false });
  }
}

createServer((request, response) => {
  const url = new URL(request.url || "/", `http://localhost:${port}`);

  if (request.method === "POST" && url.pathname === "/api/telegram") {
    handleTelegramWebhook(request, response);
    return;
  }

  const requestedPath = url.pathname === "/" ? "/index.html" : url.pathname;
  const filePath = normalize(join(root, requestedPath));

  if (!filePath.startsWith(root)) {
    response.writeHead(403);
    response.end("Forbidden");
    return;
  }

  const stream = createReadStream(filePath);
  stream.on("open", () => {
    response.writeHead(200, { "Content-Type": types[extname(filePath)] || "application/octet-stream" });
    stream.pipe(response);
  });
  stream.on("error", () => {
    response.writeHead(404);
    response.end("Not found");
  });
}).listen(port, () => console.log(`FoodLens is running at http://localhost:${port}`));
